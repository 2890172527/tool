# 用于pox工具箱


grep_prop() {
    if [[ -f "$2" ]]; then
        result=`sed -rn "s/^$1=//p" "$2" | head -n 1`
        [[ -z "$result" ]] && return 1
        cat <<-Han
			$result
		Han
    else
        return 22
    fi
        return 0 
}

Disable_All_Modules() {
    local IFS=$'\n'
    for p in /data/adb/modules /data/adb/lite_modules; do
        [[ -d $p ]] && ls $p | while read m; do
            local MODNAME=
            MODNAME=`grep_prop name "$p/$m/module.prop"`
            if [[ -f "$p/$m/disable" ]]; then
                echo "- 「$MODNAME」已在禁用状态中"
                continue
            fi
                if [[ -d "$p/$m/disable" ]]; then
                    rm -rf "$p/$m/disable"
                fi
                    echo "! 已禁用了「$MODNAME」"
                    touch "$p/$m/disable" >/dev/null
        done
    done
    echo 
    echo '- 已重启手机'
    reboot
}


Disable_All_Modules
