module=sdcard/pox/module.zip
#pox
#安洋
if ! command -v magisk &> /dev/null
then
    echo "Magisk 未安装，请确认设备已经 root 并安装了最新版本的 Magisk。"
    exit 1
fi

if ! command -v magiskinit &> /dev/null
then

#  Magisk Manager 
echo "使用 Magisk Manager 安装模块..."
magisk --install-module $module || echo "安装失败了！" 
fi
date

