#!/system/bin/sh
#-安洋制作，只为方便群友
#pox
sd=/sdcard/
dd if=/dev/block/sdf4 of=${sd}fsg.img 
dd if=/dev/block/sdf5 of=${sd}fsc.img 
dd if=/dev/block/sdf2 of=${sd}modemst1.img
dd if=/dev/block/sdf3 of=${sd}modemst2.img ||echo "备份失败，是否授权了root"