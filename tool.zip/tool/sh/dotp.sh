#!/system/bin/sh
#-安洋制作，只为方便群友
#pox
sd="./img/"
if [[ -e /dev/block/by-name/dtbo_a ]] || [[ -e /dev/block/bootdevice/by-name/dtbo_a ]]; then
  dd if=/dev/block/by-name/dtbo$(getprop ro.boot.slot_suffix) of=${sd}dtbo.img || dd if=/dev/block/bootdevice/by-name/dtbo$(getprop ro.boot.slot_suffix) of=${sd}dtbo.img
elif [[ -e /dev/block/by-name/dtbo ]] || [[ -e /dev/block/bootdevice/by-name/dtbo ]]; then
  dd if=/dev/block/by-name/dtbo of=${sd}dtbo.img || dd if=/dev/block/bootdevice/by-name/dtbo of=${sd}dtbo.img
else
  echo "备份失败，是否root运行"
  exit
fi